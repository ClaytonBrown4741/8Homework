#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<errno.h>

#include"wyscanner.h"

int main(){
    char input[256];
    char *tokens[]={ "QUOTE_ERROR", "ERROR_CHAR", "SYSTEM_ERROR",
                "EOL", "REDIR_OUT", "REDIR_IN", "APPEND_OUT",
                "REDIR_ERR", "APPEND_ERR", "REDIR_ERR_OUT", "SEMICOLON",
                "PIPE", "AMP", "WORD" };
    int commandChecker=0;
    while(1){
    printf("?> ");
    int testChecker=0;
    strncpy(input, "", 4028);

 
    fgets(input, 256, stdin);

    if (feof(stdin)){
      return 0;
    }

    testChecker=parse_line(input);
    while (testChecker != EOL){
      switch(testChecker) {
        case WORD:
          if (commandChecker==0){
            printf(":--: %s\n",lexeme);
	    commandChecker=1;
	  }
          else
            printf("--: %s\n", lexeme);
          break;
	case PIPE:
          printf("  |  \n");
          break;
        case ERROR_CHAR:
          printf("%d: %s\t =%d\n",testChecker,tokens[testChecker%96],error_char);
          break;
        default:
          printf("%d: %s\n",testChecker,tokens[testChecker%96]);
      }
      testChecker=parse_line(NULL);
    }
    fprintf(stderr,"After");
  } //   THIS IS THE WHILE ONE
  return 0;
}
